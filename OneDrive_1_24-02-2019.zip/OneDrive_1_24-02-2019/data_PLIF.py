import scipy.io as sio
import numpy as np
import pandas as pd

def get_data():
    input_file=sio.loadmat('data.mat')
    input_matrix = input_file['data']
    cross_correlation_32 = pd.read_csv('cross_correlation_32.csv', sep=',',header=0, index_col = False, usecols=['x','y','U_pix','V_pix'])
    data = np.concatenate((input_matrix,cross_correlation_32),axis=1)
    np.random.shuffle(data)
    X_train = data[0:37107,0:128]
    m=X_train.shape(0);
    np.reshape(X_train,(m,8,8,2));
    Y_train = data[0:37107,130:132]
    X_valid = data[37107:49476,0:128]
    m=X_valid.shape(0);
    np.reshape(X_valid,(m,8,8,2));
    Y_valid = data[37107:49476,130:132]
    X_test = data[49476:,0:128]
    m=X_test.shape(0);
    np.reshape(X_test,(m,8,8,2));
    Y_test = data[49476:,130:132]
    return X_train, Y_train, X_valid, Y_valid, X_test, Y_test;

